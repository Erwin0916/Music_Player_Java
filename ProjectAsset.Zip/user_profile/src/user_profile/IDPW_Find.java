package user_profile;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class IDPW_Find extends JFrame{
	
	public IDPW_Find() {
		
	setTitle("ID/PW ã��");

	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	JLabel ID = new JLabel("ID �Է�");
	JTextField ID_Field = new JTextField(20);	
	JButton Submit = new JButton("Submit");
	JButton Back_btn = new JButton("Back");
	
	c.add(ID);
	c.add(ID_Field);
	c.add(Submit);
	c.add(Back_btn);
	
	Submit.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			int pass=0;
	
            try {
            	BufferedReader br = new BufferedReader(new FileReader("members.txt"));
                String line ="";
                try {
                	while((line = br.readLine())!=null)
						{
                			String[] array = line.split("/");
                			
                			if(array[0].equals(ID_Field.getText()))
                			{
                				
                						pass=1;
                						IDPW.ID_IN=array[0];
                						IDPW.PASSWARD_IN=array[1];
                						IDPW.NAME_IN=array[2];
                						IDPW.PHONE_NUMBER_IN=array[3];
                						IDPW.ADDRESS_IN=array[4];
                						setVisible(false);
                						new Phone_Certification();
                						break;
                						
                			}
						}	
					if(pass ==0) 
					{
						br.close();
						JOptionPane.showMessageDialog(null, "���� ���̵��Դϴ�!");
					}
                }catch(IOException g) {
                	g.printStackTrace();
                }
                
            }catch(FileNotFoundException g) {
            	g.printStackTrace();
            }
			
			
			
		}
		});
	Back_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			
			new user_log();
			setVisible(false);
			
		}
		});

	
	setSize(400,500);
	setVisible(true);
	
	}
	
	
	
	

}
