package user_profile;


import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class MyList extends JFrame{
	
		static JScrollPane			scrollPlayList;
		static Object alpa=null;
	public MyList() {
		
		setTitle("��� ���");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		
		JButton Add_Chart_btn = new JButton("�߰�");
		JButton Delete_btn = new JButton("����");
		JLabel labelPlayList = new JLabel("��� ���");
		JButton Re_btn = new JButton("��Ʈ����");
		labelPlayList.setBounds(20, 50, 40, 25);
		labelPlayList.setFocusable(false);
		DefaultListModel model = new DefaultListModel();
		JList box = new JList(model);
		box.setBounds(40,30, 100, 100);
		scrollPlayList = new JScrollPane();
		scrollPlayList.setBounds(20, 400, 406, 270);
		scrollPlayList.setFocusable(false);
		scrollPlayList.setViewportView(box);
		c.add(labelPlayList);
		c.add(scrollPlayList);
		c.add(Add_Chart_btn);
		c.add(Re_btn);
		c.add(Delete_btn);
		
		box.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
            	
            	alpa=box.getSelectedValue();
            	new Show_Music_List();
            	setVisible(false);
            }
		});
		 Re_btn.addActionListener(new ActionListener() { 
				public void actionPerformed(ActionEvent e) {	
						String chart="";
						String[] array=null;
						model.clear();
					 try {	 
				         BufferedReader br2 = new BufferedReader(new FileReader(IDPW.ID_IN+"\\������_����Ʈ.txt"));
			             String line ="";
			                 
			                 try {
			                 	while((line = br2.readLine())!=null)
										{
			                 			 array = line.split("/");		
										}	
			                 }catch(IOException g) {
			                 	g.printStackTrace();
			                 }
			                 for(int i=0;i<array.length;i++)
			                 {
			                	 model.addElement(array[i]);
			                	 chart=chart+array[i]+"\n";
			                 }
			             }catch(FileNotFoundException g) {
			             	g.printStackTrace();
			             }
					 	
				
					 	
			}
			});
		
		Add_Chart_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				
				new Add_Check();
				
				
			}
			
		});
		Delete_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				new Delete_Check();

			}
			
		});

		setSize(400,400 );
		setVisible(true);

	}	
}
class OpenFile_MyList implements ActionListener {

	static String PATH="";
	public void actionPerformed(ActionEvent e) {
		JFileChooser CHOOSER = new JFileChooser();
		
		FileNameExtensionFilter filter = new FileNameExtensionFilter ("WAV, MP3", "wav", "mp3" );
		
		CHOOSER.setFileFilter(filter);
		CHOOSER.setMultiSelectionEnabled(true);

		int ret = CHOOSER.showOpenDialog(null);		
	
		if ( ret != JFileChooser.APPROVE_OPTION ) {
			JOptionPane.showMessageDialog(null, "������ �������� �ʾҽ��ϴ�.", 
					"���", JOptionPane.WARNING_MESSAGE);
			return;
		}
	
		for (File file : CHOOSER.getSelectedFiles()) {
			if(PATH=="")
    			PATH =file.getPath();
    		else
    			PATH =PATH+"\n"+file.getPath();

		}
	}
}
class My_PlayList {
	private static Vector<String> 		AUDIO_LIST = new Vector<String>();	
	private static Vector<String>		NAME_LIST = new Vector<String>();	
	static String name="";
	static String name2 ="";
	static String str="";
	
	/**
	 * ���ϰ�θ� �޾� ������ ��ο� �̸��� ���� 
	 * <br> AUDIO_LIST, NAME_LIST ���Ϳ� �߰������ִ� �޼ҵ��Դϴ�.
	 * @param filepath ���� ������ ������ ������ ���
	 * @author jihun
	 */
	public static void add(String filepath) {
 	


		String[] splitedPath = filepath.split("\\\\");
		name = splitedPath[splitedPath.length - 1];
		String[] splitedName = name.split("\\.");
		name2 =splitedName[splitedName.length - 2];
		if(str.equals(""))
		{
			str=str+name2;
		
		}
		else if(str!=null){
		str=str+"/"+name2;
		}
		if(!(splitedName[splitedName.length - 1].equals("wav")) && !(splitedName[splitedName.length - 1].equals("mp3"))) {
			JOptionPane.showMessageDialog(null, "�������� �ʴ� ���� �����Դϴ�..", 
					"���", JOptionPane.WARNING_MESSAGE);
			return;
		}
}}
class Add_Check extends JFrame{
	
	static int check=0;
	public Add_Check() {
		
		setTitle("������ ����");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		
		JButton Add_Chart_btn = new JButton("�߰�");
		JButton cancle_btn = new JButton("cancle");
		JTextField List_Field = new JTextField(20);
		JLabel List = new JLabel("�̸�");
		c.add(List);
		c.add(List_Field);
		c.add(Add_Chart_btn);
		c.add(cancle_btn);
		
		Add_Chart_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				String[] array=null;
				String line ="";
				String line2 ="";
				
				try{

					  boolean isOk = false;
		              BufferedWriter bw = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\"+List_Field.getText()+".txt", true));
		              BufferedReader br = new BufferedReader(new FileReader(IDPW.ID_IN+"\\"+List_Field.getText()+".txt"));
		              BufferedWriter bw2 = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\������_����Ʈ.txt", true));
		              BufferedReader br2 = new BufferedReader(new FileReader(IDPW.ID_IN+"\\������_����Ʈ.txt"));
		              while((line2=br2.readLine())!=null)
		              {
		            	  array= line2.split("/");
		            	  for(int i=0;i<array.length;i++)
			              {
		            		  if(array[i].equals(List_Field.getText()))
		            		  check=1;
			              }
		              }     
		              
		              if(check==1)
		              {
		            	  JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ������ �Դϴ�.");
		              }
		              bw2.close();
		              		if(!isOk) {           	
		                        bw.close();
	                        }
		              		if(check!=1)
		              		{
		              		BufferedWriter bw3 = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\������_����Ʈ.txt", true));
		              		BufferedReader br3 = new BufferedReader(new FileReader(IDPW.ID_IN+"\\������_����Ʈ.txt"));
	                        if((line = br3.readLine())==null)
	                        {         	
	                        	bw3.write(List_Field.getText());
	                        }
	                        else if(line!=null)
	                        {
	                        	bw3.write("/");
	                        	bw3.write(List_Field.getText());	    
	                        }
	                        bw3.close();
		              		}
					  }
					     
					catch (IOException  ex)
					{
		                JOptionPane.showMessageDialog(null, "����");
					}
				check=0;
				setVisible(false);
			}
		});
		cancle_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				setVisible(false);
			}
		});

		setSize(400,200 );
		setVisible(true);
	}
}
class Delete_Check extends JFrame{
	public Delete_Check() {
		
		setTitle("����");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		JButton Delete_Chart_btn = new JButton("����");
		JButton cancle_btn = new JButton("cancle");
		JTextField List_Field = new JTextField(20);
		JLabel List = new JLabel("�̸�");
		c.add(List);
		c.add(List_Field);
		c.add(Delete_Chart_btn);
		c.add(cancle_btn);
		
		Delete_Chart_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				try {
					int check=0;
					String line="";
					String chart="";
					String[] array=null;
					File file = new File(IDPW.ID_IN+"\\"+List_Field.getText()+".txt");
					BufferedWriter bw2 = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\������_����Ʈ.txt", true));
		            BufferedReader br2 = new BufferedReader(new FileReader(IDPW.ID_IN+"\\������_����Ʈ.txt"));
		          
		            try {
	                 	while((line = br2.readLine())!=null)
								{
	                 			array = line.split("/");
								}
	                 	
	                 	for(int i=0;i<array.length;i++) {
	                 		if(array[i].equals(List_Field.getText()))
	                 		{
	                 			check=i+1;
	                 			break;
	                 		}
	                 		if(chart=="")
	                 			chart=chart+array[i];
	                 		else
	                 			chart=chart+"/"+array[i];
	                 		}
	                 	for(int i=check;i<array.length;i++) {
	                 		if(chart=="")
	                 			chart=chart+array[i];
	                 		else
	                 			chart=chart+"/"+array[i];
	                 	}
				
	                 	bw2.close();
	                 	
	                 	System.gc();
			            file.delete();
	                 }catch(IOException g) {
	                 	g.printStackTrace();
	                 }
		       if(check==0)
		    	   JOptionPane.showMessageDialog(null, "�������� �ʴ� ������ �Դϴ�.");
		       if(check!=0)
		       {
				new FileOutputStream(IDPW.ID_IN+"\\������_����Ʈ.txt").close();
				BufferedWriter bw3 = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\������_����Ʈ.txt", true));
	            BufferedReader br3 = new BufferedReader(new FileReader(IDPW.ID_IN+"\\������_����Ʈ.txt"));
	            bw3.write(chart);
	            bw3.close();
		       }
				}
				
				catch (IOException ex)
				{
	                JOptionPane.showMessageDialog(null, "����");
				}
				setVisible(false);
			}
		});
		cancle_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				setVisible(false);
			}
		});

		setSize(400,200 );
		setVisible(true);
	}
}

class Show_Music_List extends JFrame{
	static String[] list=null;
	static JScrollPane scrollPlayList;
	String[] s1=null;
	public Show_Music_List() {
		
		setTitle("���Ǹ��");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		DefaultListModel model = new DefaultListModel();
		JList box = new JList(model);
		box.setBounds(40,30, 100, 100);
		scrollPlayList = new JScrollPane();
		scrollPlayList.setBounds(20, 400, 406, 270);
		scrollPlayList.setFocusable(false);
		scrollPlayList.setViewportView(box);
		c.add(scrollPlayList);
		JButton Add_Chart_btn = new JButton("�߰�");
		JButton cancle_btn = new JButton("back");
		JButton Add_Main_btn = new JButton("���ο��� ����ϱ�");
		JButton Re_btn = new JButton("��ϰ���");
		JButton Delete_btn = new JButton("����");
		JLabel list_name =new JLabel((String) MyList.alpa);
		c.add(list_name);
		c.add(Add_Chart_btn);
		c.add(cancle_btn);
		c.add(Add_Main_btn);
		c.add(Re_btn);
		c.add(Delete_btn);
		
		Add_Main_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] splitedPath=null;
				String line=null;
				
				try {
					PlayList.playlist_clear();
					BufferedReader br = new BufferedReader(new FileReader(IDPW.ID_IN+"\\"+MyList.alpa+".txt")); 
				
					while((line=br.readLine())!=null)
					{
						PlayList.add(line);
		            }
					}catch (IOException ex)
					{
		                JOptionPane.showMessageDialog(null, "����");
				    }
				setVisible(false);
			}
		});
		Delete_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				new Remove_check();
				
			}
		});
		Re_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				model.clear();	  
				String s=null;
				String line=null;
				String[] splitedName=null;
	            String[] splitedPath=null;
	            String name=null;
				try {
				BufferedReader br = new BufferedReader(new FileReader(IDPW.ID_IN+"\\"+MyList.alpa+".txt"));  
				while((line=br.readLine())!=null)
	            {
	            splitedPath = line.split("\\\\");
	    		name = splitedPath[splitedPath.length - 1];
	    		splitedName = name.split("\\.");
	    		if(s=="")
	    		{
	    			s=splitedName[splitedName.length - 2];
	            }else 
	            {
	            	s=s+"/"+splitedName[splitedName.length - 2];
	            }
	            }
				s1= s.split("/");
				for(int i=1;i<s1.length;i++)
                {
               	 model.addElement(s1[i]);
                }	
				}catch (IOException ex)
				{
	                JOptionPane.showMessageDialog(null, "����");
				}
			}
		});		
		Add_Chart_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				OpenFile_MyList a =new OpenFile_MyList();
				a.actionPerformed(null);
				try 
				{
	
				BufferedWriter bw = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\"+MyList.alpa+".txt", true));            
	            bw.write(OpenFile_MyList.PATH+"\n");      
	            OpenFile_MyList.PATH="";
	            bw.close();
				}
				catch (IOException ex)
				{
	                JOptionPane.showMessageDialog(null, "����");
				}
				
			}
		});
		
		cancle_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {		
				setVisible(false);
				new MyList();
			}
		});
		
		setSize(400,400 );
		setVisible(true);
	}
}
class Remove_check extends JFrame{

	public Remove_check() {
		
		setTitle("���Ǹ��");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));

		JButton cancle_btn = new JButton("cancle");
		JButton Delete_btn = new JButton("����");
		JTextField list_name = new JTextField(10);
		c.add(list_name);
		c.add(cancle_btn);
		c.add(Delete_btn);
		
		Delete_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				try {
					String s = null;
					String name = null;
					BufferedWriter bw = new BufferedWriter(new FileWriter(IDPW.ID_IN+"\\"+MyList.alpa+".txt", true));
					BufferedReader br = new BufferedReader(new FileReader(IDPW.ID_IN+"\\"+MyList.alpa+".txt"));
					String line;
					String dummy="";
					String[] array=null;
					String[] array2=null;
					int check=0;
					while(true) {	                  
						
	                    line = br.readLine();
	                    s=line;               
	                    array = s.split("\\\\");      
	    	    		name = array[array.length - 1];	
	    	    		array2 = name.split("\\.");
	                    if(array2[0].equals(list_name.getText()))
	        			{	check=1;
	                    	break;	
	        			}
	                    if(dummy=="")
	                    dummy=line + "\n"; 
	                    else
	                    dummy=dummy+line + "\n"; 
	                } 
					while((line = br.readLine())!=null) {

						dummy += (line + "\n" ); 

					}
					bw.close();

						FileWriter fw = new FileWriter(IDPW.ID_IN+"\\"+MyList.alpa+".txt");		
						fw.write(dummy);			 
						fw.close();
					
					if(check==0){
						JOptionPane.showMessageDialog(null, "�����Ͽ� ���� �����Դϴ�.");
					}
					br.close();

				} catch (Exception g) {

					// TODO Auto-generated catch block

					g.printStackTrace();

				}
				setVisible(false);
			}
		});
		cancle_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				
				setVisible(false);
			}
		});
		
		setSize(400,200 );
		setVisible(true);
	}
}













