package user_profile;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

class IDPW
{
	static String ID_IN=null;
	static String PASSWARD_IN=null;
	static String NAME_IN=null;
	static String PHONE_NUMBER_IN=null;
	static String ADDRESS_IN=null;
	static String CHECK_IN=null;
}
public class user_log extends JFrame{
	

	public user_log() {
		
		setTitle("�α��� ");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		JLabel ID = new JLabel("ID                   ");
		JTextField ID_Field = new JTextField(20);
		JLabel PASSWARD = new JLabel("PASSWARD");
		JTextField PASSWARD_Field = new JTextField(20);	
		JButton Log_In_btn = new JButton("Log In");
		JButton Sign_Up_btn = new JButton("Sign Up");
		JButton Forgot_Passward_btn = new JButton("Forgot Passward");
		c.add(ID);
		c.add(ID_Field);
		c.add(PASSWARD);
		c.add(PASSWARD_Field);
		c.add(Log_In_btn);
		c.add(Sign_Up_btn);
		c.add(Forgot_Passward_btn);
		
	
		Sign_Up_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				new Sign_up();
				setVisible(false);
				
			}
			});
		Forgot_Passward_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				new IDPW_Find();
				setVisible(false);
				
			}
			});
		
		Log_In_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
				
				int pass=0;
		
				
                try {
                	BufferedReader br = new BufferedReader(new FileReader("members.txt"));
                    String line ="";
                    try {
                    	while((line = br.readLine())!=null)
							{
                    			
                    			String[] array = line.split("/");
                    			
                    			if(array[0].equals(ID_Field.getText()))
                    			{
                    				if(array[1].equals(PASSWARD_Field.getText()))
                    						{pass=1;
                    						IDPW.ID_IN=array[0];
                    						IDPW.PASSWARD_IN=array[1];
                    						IDPW.NAME_IN=array[2];
                    						IDPW.PHONE_NUMBER_IN=array[3];
                    						IDPW.ADDRESS_IN=array[4];
                    						IDPW.CHECK_IN=array[5];
                    						
												new log_in();
									
                    						setVisible(false);
                    						break;
                    						}
                    			}
							}	
						if(pass ==0) 
						{
						
							br.close();
							JOptionPane.showMessageDialog(null, "���̵� �Ǵ� ��й�ȣ�� ���� �ʽ��ϴ�!");
						}
                    }catch(IOException g) {
                    	g.printStackTrace();
                    }
                    
                }catch(FileNotFoundException g) {
                	g.printStackTrace();
                }

			}
			});

		
		setSize(400,300 );
		setVisible(true);

	}
	
	
	public static void main(String[] args) {
		
		user_log a = new user_log();
	}

}
