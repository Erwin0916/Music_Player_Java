package user_profile;
import java.util.*;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PlayList {
	private static Vector<String> 		AUDIO_LIST = new Vector<String>();	
	private static Vector<String>		NAME_LIST = new Vector<String>();	

	private static JList<?> 			playList;						
	static int 					playNo = 0;						

	
	public static void add(String filepath) {
		String[] splitedPath = filepath.split("\\\\");
		String name = splitedPath[splitedPath.length - 1];
		String[] splitedName = name.split("\\.");
		if(!(splitedName[splitedName.length - 1].equals("wav")) && !(splitedName[splitedName.length - 1].equals("mp3"))) {
			JOptionPane.showMessageDialog(null, "�������� �ʴ� ���� �����Դϴ�..", 
					"���", JOptionPane.WARNING_MESSAGE);
			return;
		}

		
		AUDIO_LIST.add(filepath);   
		NAME_LIST.add(name);
		
		playList = new JList<Object>(NAME_LIST);
		JListHandler handler = new JListHandler();
		playList.addListSelectionListener(handler);
		playList.setFocusable(false);
		log_in.updateList(playList);
	}
	
	public static void playlist_clear() {
		NAME_LIST.removeAllElements();
	}

	
	public static int getplayNo() {
		return playNo;
	}

	
	public static void setplayNo(int playNo) {
		PlayList.playNo = playNo;
	}

	
	public static void nextFile() {
		if(playNo + 1 > AUDIO_LIST.size() - 1) {
			playNo = 0;
		}
		else {
			playNo++;
		}
	}

	
	public static void prevFile() {
		if(playNo - 1 < 0) {
			playNo = AUDIO_LIST.size() - 1;
		}
		else {
			playNo--;
		}
	}

	
	public static int getListSize() {
		return AUDIO_LIST.size();
	}


	public static String getPath() {
		return AUDIO_LIST.get(playNo);
	}


	public static class JListHandler implements ListSelectionListener
	{
		
		public void valueChanged(ListSelectionEvent arg0) {	
			playNo = playList.getSelectedIndex();
		}
	}
}