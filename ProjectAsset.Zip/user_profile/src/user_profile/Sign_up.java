package user_profile;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;


class Phone{
	static String Phone_Num=null;
}
public class Sign_up extends JFrame{
	
	public Sign_up() {
	setTitle("ȸ�� ����");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	
	JLabel ID = new JLabel("ID                           ");
	JTextField ID_Field = new JTextField(20);
	JLabel PASSWARD = new JLabel("PASSWARD        ");
	JTextField PASSWARD_Field = new JTextField(20);	
	JLabel NAME = new JLabel("NAME                    ");
	JTextField NAME_Field = new JTextField(20);	
	JLabel PHONE_NUMBER = new JLabel("PHONE NUMBER");
	JTextField PHONE_NUMBER_Field = new JTextField(20);	
	JLabel ADDRESS = new JLabel("ADDRESS            ");
	JTextField ADDRESS_Field = new JTextField(20);	
	JLabel Certification_Number = new JLabel("���� ��ȣ");
	JTextField Certification_Number_Field = new JTextField(20);	
	JButton Send = new JButton("���� ��ȣ ����");
	JButton Submit_btn = new JButton("Submit");
	JButton Cancle_btn = new JButton("Cancle");
	
	c.add(ID);
	c.add(ID_Field);
	c.add(PASSWARD);
	c.add(PASSWARD_Field);
	c.add(NAME);
	c.add(NAME_Field);
	c.add(PHONE_NUMBER);
	c.add(PHONE_NUMBER_Field);
	c.add(ADDRESS);
	c.add(ADDRESS_Field);
	c.add(Certification_Number);
	c.add(Certification_Number_Field);
	c.add(Send);
	c.add(Submit_btn);
	c.add(Cancle_btn);
	
	
	Submit_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			if(Certification_Number_Field.getText().equals("1234"))
			{
	
			try{
                String s = null;
                boolean isOk = false;
                BufferedWriter bw = new BufferedWriter(new FileWriter("members.txt", true));
                BufferedReader br = new BufferedReader(new FileReader("members.txt"));
                
                
                if(e.getSource() == Submit_btn) {
                    while((s = br.readLine()) != null) {
                        
                        // ���̵� �ߺ�
                        String[] array = s.split("/");
                        if(array[0].equals(ID_Field.getText())){
                                isOk = true;
                                JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ���̵��Դϴ�.");
                                break;
                        }
                    }
                            //���� �Է½� �ߺ��� ������ ������ ����
                            if(!isOk) {
                            bw.write(ID_Field.getText() + "/");
                            bw.write(PASSWARD_Field.getText() + "/");
                            bw.write(NAME_Field.getText() + "/");
                            bw.write(PHONE_NUMBER_Field.getText() + "/");
                            bw.write(ADDRESS_Field.getText() + "/");
                            bw.write("visible" + "\r\n");
                            bw.close();
                            	String path = ID_Field.getText(); //���� ���
                            	File Folder = new File(path);

                            	// �ش� ���丮�� ������� ���丮�� �����մϴ�.
                            	if (!Folder.exists()) {
                            		try{
                            		    Folder.mkdir(); //���� �����մϴ�.   
                            	        } 
                            	        catch(Exception k){
                            		    k.getStackTrace();
                            		}        
                                    
                                }
                            	 JOptionPane.showMessageDialog(null, "ȸ�������� �����մϴ�.");
                            	 new user_log();
                     			setVisible(false);
                            }
                            }else {
                                JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ���̵��Դϴ�.");
                            }   
                }
			
			catch (IOException  ex)
			{
                JOptionPane.showMessageDialog(null, "����");
            }
			
			}
			else if(!Certification_Number_Field.getText().equals("1234"))
				 JOptionPane.showMessageDialog(null, "������ȣ�� ���� �ʽ��ϴ�.");
		}
		});
	
		Cancle_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
		new user_log();
    	setVisible(false);

		}
		});
		
		Send.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			
			new Certification_Number();
	    	
			}
			});
    
	
	setSize(400,500 );
	setVisible(true);
	
	}
	
	
	
	

}
