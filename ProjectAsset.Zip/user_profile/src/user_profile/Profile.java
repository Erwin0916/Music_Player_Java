package user_profile;



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Profile extends JFrame{
	public Profile() {
		
	setTitle("Profile");
	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	JLabel ID = new JLabel("ID                           ");
	JTextField ID_Field = new JTextField(null,20);
	JLabel PASSWARD = new JLabel("PASSWARD        ");
	JTextField PASSWARD_Field = new JTextField(null,20);	
	JLabel NAME = new JLabel("NAME                    ");
	JTextField NAME_Field = new JTextField(null,20);	
	JLabel PHONE_NUMBER = new JLabel("PHONE NUMBER");
	JTextField PHONE_NUMBER_Field = new JTextField(null,20);	
	JLabel ADDRESS = new JLabel("ADDRESS            ");
	JTextField ADDRESS_Field = new JTextField(null,20);	
	JButton Modify_btn = new JButton("Modify");
	JButton Back_btn = new JButton("Back");
	JButton Vis_btn = new JButton("����");
	JButton UnVis_btn = new JButton("�����");
	c.add(ID);
	c.add(ID_Field);
	c.add(PASSWARD);
	c.add(PASSWARD_Field);
	c.add(NAME);
	c.add(NAME_Field);
	c.add(PHONE_NUMBER);
	c.add(PHONE_NUMBER_Field);
	c.add(ADDRESS);
	c.add(ADDRESS_Field);
	c.add(Modify_btn);
	c.add(Back_btn);
	c.add(Vis_btn);
	c.add(UnVis_btn);
	String[] array=null;
	
	try {
		String s = null;
		BufferedReader br = new BufferedReader(new FileReader("members.txt"));
		String line;
		while(true) {
            line = br.readLine();
            s=line;
            array = s.split("/");
       
            if(array[0].equals(IDPW.ID_IN))
			{
				if(array[1].equals(IDPW.PASSWARD_IN))
						{
						break;
						}
			}
        } 
		br.close();

	} catch (Exception g) {

		g.printStackTrace();

	}		    	
	
	 if(array[5].equals("visible")) {
		ID_Field.setText(IDPW.ID_IN);
		PASSWARD_Field.setText(IDPW.PASSWARD_IN);
		NAME_Field.setText(IDPW.NAME_IN);
		PHONE_NUMBER_Field.setText(IDPW.PHONE_NUMBER_IN);
		ADDRESS_Field.setText(IDPW.ADDRESS_IN);
	 }
	else if(array[5].equals("private"))
	{
		ID_Field.setText("�����");
		PASSWARD_Field.setText("�����");
		NAME_Field.setText("�����");
		PHONE_NUMBER_Field.setText("�����");
		ADDRESS_Field.setText("�����");
	}
	
	Modify_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			
			int result = JOptionPane.showConfirmDialog(null,"�����Ͻðڽ��ϱ�?","Confirm",JOptionPane.YES_NO_OPTION);
			if(result==JOptionPane.YES_OPTION)
			{
				
				try {
					String dummy = "";
					String line="";
					String s="";
					String[] array=null;
					BufferedWriter bw = new BufferedWriter(new FileWriter("MusicChart.txt", true));
					BufferedReader br = new BufferedReader(new FileReader("MusicChart.txt"));
					
					while((line = br.readLine())!=null) {
	                    s=line;
	                    array = s.split("/");
   
	        				if(array[2].equals(IDPW.ID_IN))
		        			{
		                    	dummy += (array[0]+"/"+array[2]+"/"+ID_Field.getText()+"\n" );
		        			}
	        				else
	        					dummy += (line + "\n" ); 
	                    
	                } 		
					
				
					FileWriter fw = new FileWriter("MusicChart.txt");

					fw.write(dummy);			


					bw.close();

					fw.close();

					br.close();
				}catch (Exception g) {

					// TODO Auto-generated catch block

					g.printStackTrace();

				}
				String dummy = "";
				try {
					String s = null;
					BufferedWriter bw = new BufferedWriter(new FileWriter("members.txt", true));
					BufferedReader br = new BufferedReader(new FileReader("members.txt"));
					String line;

					while(true) {
	                    line = br.readLine();
	                    s=line;
	                    String[] array = s.split("/");
	                    
	                    if(array[0].equals(IDPW.ID_IN))
	        			{
	        				if(array[1].equals(IDPW.PASSWARD_IN))
	        						{
	        						break;
	        						}
	        			}
	                    dummy += (line + "\n" ); 
	                } 
				dummy += (ID_Field.getText()+"/"+PASSWARD_Field.getText()+"/"+NAME_Field.getText()+"/"+PHONE_NUMBER_Field.getText()+"/"+ADDRESS_Field.getText()+"/"+IDPW.CHECK_IN+"\n" ); 
				File file1 = new File(IDPW.ID_IN);
				IDPW.ID_IN=ID_Field.getText();
				IDPW.PASSWARD_IN=PASSWARD_Field.getText();
				IDPW.NAME_IN=NAME_Field.getText();
				IDPW.PHONE_NUMBER_IN=PHONE_NUMBER_Field.getText();
				IDPW.ADDRESS_IN=ADDRESS_Field.getText();
				 
				File file2 = new File(ID_Field.getText());

				    if (!file1.renameTo(file2)) {
				      System.err.println("�̸� ���� ���� : " + file1);
				    }
				
				String delData = br.readLine();

				while((line = br.readLine())!=null) {

					dummy += (line + "\n" ); 

				}
			
				FileWriter fw = new FileWriter("members.txt");

				fw.write(dummy);			


				bw.close();

				fw.close();

				br.close();

			} catch (Exception g) {

				// TODO Auto-generated catch block

				g.printStackTrace();

			}
			
		
	    	JOptionPane.showMessageDialog(null, "���� �Ϸ�!");
	    	
			new Profile();
			setVisible(false);
			}
			
		}
		
		});
	Back_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
		
			
			new log_in();
			
			setVisible(false);
			
			
		}
		});
	
	Vis_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			ID_Field.setText(IDPW.ID_IN);
			PASSWARD_Field.setText(IDPW.PASSWARD_IN);
			NAME_Field.setText(IDPW.NAME_IN);
			PHONE_NUMBER_Field.setText(IDPW.PHONE_NUMBER_IN);
			ADDRESS_Field.setText(IDPW.ADDRESS_IN);
			String dummy="";
			try {
				String s = null;
				BufferedWriter bw = new BufferedWriter(new FileWriter("members.txt", true));
				BufferedReader br = new BufferedReader(new FileReader("members.txt"));
				String line;
				String[] array;
				while(true) {
                    line = br.readLine();
                    s=line;
                    array = s.split("/");
               
                    if(array[0].equals(IDPW.ID_IN))
        			{
        				if(array[1].equals(IDPW.PASSWARD_IN))
        						{
        						break;
        						}
        			}
                    dummy += (line + "\n" ); 
                } 
				if(dummy=="")
				{
				 dummy= (array[0]+"/"+array[1]+"/" +array[2] +"/"+array[3] +"/"+array[4] +"/visible\n" ); 
				}
				else
				{
				dummy+= (array[0]+"/"+array[1]+"/" +array[2] +"/"+array[3] +"/"+array[4] +"/visible\n" ); 
				}	
				while((line = br.readLine())!=null) {

					dummy += (line + "\n" ); 

				}
			
				FileWriter fw = new FileWriter("members.txt");

				fw.write(dummy);			


				bw.close();

				fw.close();

				br.close();

			} catch (Exception g) {

				g.printStackTrace();

			}		    	
			
			
		}
		});
	UnVis_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			ID_Field.setText("�����");
			PASSWARD_Field.setText("�����");
			NAME_Field.setText("�����");
			PHONE_NUMBER_Field.setText("�����");
			ADDRESS_Field.setText("�����");
			String dummy="";
			try {
				String s = null;
				BufferedWriter bw = new BufferedWriter(new FileWriter("members.txt", true));
				BufferedReader br = new BufferedReader(new FileReader("members.txt"));
				String line;
				String[] array;
				while(true) {
                    line = br.readLine();
                    s=line;
                    array = s.split("/");
               
                    if(array[0].equals(IDPW.ID_IN))
        			{
        				if(array[1].equals(IDPW.PASSWARD_IN))
        						{
        						break;
        						}
        			}
                    dummy += (line + "\n" ); 
                } 
				if(dummy=="")
				{
				 dummy= (array[0]+"/"+array[1]+"/" +array[2] +"/"+array[3] +"/"+array[4] +"/private\n" ); 
				}
				else
				{
				dummy+= (array[0]+"/"+array[1]+"/" +array[2] +"/"+array[3] +"/"+array[4] +"/private\n" ); 
				}	
				while((line = br.readLine())!=null) {

					dummy += (line + "\n" ); 

				}
			
				FileWriter fw = new FileWriter("members.txt");

				fw.write(dummy);			


				bw.close();

				fw.close();

				br.close();

			} catch (Exception g) {

				g.printStackTrace();

			}		    	
			}
		});

	
	setSize(400,500);
	setVisible(true);
	
	}
	
	
	
	

}
