package user_profile;

import javax.swing.*;

import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Vector;

public class Music_Chart extends JFrame{

	static String chart="";
	public Music_Chart(){
		
	
			setTitle("������Ʈ");
			Container c = getContentPane();
			c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
			JButton Add_Chart_btn = new JButton("�߰�");
			JButton Delete_btn = new JButton("����");
			JLabel labelPlayList = new JLabel("������Ʈ");
			JButton Re_btn = new JButton("��Ʈ����");
			JButton Find_btn = new JButton("���ǰ˻�");
			labelPlayList.setBounds(20, 370, 120, 25);
			labelPlayList.setFocusable(false);
			TextArea box = new TextArea();
			c.add(labelPlayList);
			c.add(box);
			c.add(Add_Chart_btn);
			c.add(Re_btn);
			c.add(Delete_btn);
			c.add(Find_btn);
			
			Find_btn.addActionListener(new ActionListener() {
				 
				public void actionPerformed(ActionEvent e) {
					
					new Find();
				}
			});
			
			
			 Re_btn.addActionListener(new ActionListener() {
				 
					public void actionPerformed(ActionEvent e) {	
							chart="";
						 try {
				             	BufferedReader br = new BufferedReader(new FileReader("MusicChart.txt"));
				                 String line ="";
				                 
				                 try {
				                 	while((line = br.readLine())!=null)
											{
				                 			
				                 			String[] array = line.split("/");
				                 			chart = (chart+array[0]+"/"+array[1]+"\n");
				                 			
											}	
				                 }catch(IOException g) {
				                 	g.printStackTrace();
				                 }
				          
				             }catch(FileNotFoundException g) {
				             	g.printStackTrace();
				             }
						
						 	
						 	box.setText(chart);
	
				}
				});
			Delete_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {	
						new Delete_Music_Chart();
						
				}
				});
			
			
			Add_Chart_btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					
					new AddChart();
					
					
				}
				});
		
			
			setSize(600,400 );
			setVisible(true);
	
	}
	
}
class AddChart extends JFrame{
	public AddChart(){
		
	
			setTitle("������Ʈ �߰�");
			Container c = getContentPane();
			c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
			JButton Add_Chart_btn = new JButton("�߰�");
			JButton cancle_btn = new JButton("cancle");
			JLabel Name = new JLabel("����: ");
			JTextField Name_Field =  new JTextField(10);
			JLabel Song = new JLabel("����: ");
			JTextField Song_Field =  new JTextField(10);
			c.add(Name);
			c.add(Name_Field);
			c.add(Song);
			c.add(Song_Field);
			c.add(Add_Chart_btn);
			c.add(cancle_btn);
			

			
			cancle_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {	
						setVisible(false);
						
				}
				});
			
			
			Add_Chart_btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					String s = null;
	                boolean isOk = false;
					try {
					BufferedWriter bw = new BufferedWriter(new FileWriter("MusicChart.txt",true));
					BufferedReader br = new BufferedReader(new FileReader("MusicChart.txt"));
					
					if(e.getSource() == Add_Chart_btn) {
	                    while((s = br.readLine()) != null) {
	                        
	                        // ���̵� �ߺ�
	                        String[] array = s.split("/");
	                        if(array[0].equals(Name_Field.getText())){
	                        	if(array[1].equals(Song_Field.getText())) {
	                        
	                                isOk = true;
	                                JOptionPane.showMessageDialog(null, "�̹� ��ϵ� ���Դϴ�.");
	                                break;
	                        }
	                    }
	                    }}
					if(!isOk) {
					bw.write(Name_Field.getText()+"/");
					bw.write(Song_Field.getText()+"/");
					bw.write(IDPW.ID_IN+"\n");
					br.close();
					bw.close();
					setVisible(false);
					}}
					catch(IOException g) {
		             	g.printStackTrace();
		             }
				
					
				
				}
				});
		
			
			setSize(500,200 );
			setVisible(true);
	
	}
	
}
class Find extends JFrame{
	static JScrollPane			ChartPlayList;
	public Find(){
		
	
			setTitle("������Ʈ");
			Container c = getContentPane();
			c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
			JButton Find_btn = new JButton("�˻�");
			JButton cancle_btn = new JButton("cancle");
			JLabel Name = new JLabel("����: ");
			JTextField Name_Field =  new JTextField(10);
			TextArea box = new TextArea();
			c.add(box);
			c.add(Name);
			c.add(Name_Field);
			c.add(Find_btn);
			c.add(cancle_btn);
			

			
			cancle_btn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {	
						setVisible(false);
						
				}
				});
			
			
			Find_btn.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {	
					int t=0;
					String chart="";
					 try {
			             	BufferedReader br = new BufferedReader(new FileReader("MusicChart.txt"));
			                 String line ="";
			                 
			                 try {
			                 	while((line = br.readLine())!=null)
										{
			                 			
			                 			String[] array = line.split("/");
			                 			if(array[0].equals(Name_Field.getText()))
			                 			{
			                 				t=1;
			                 				chart=chart+array[0]+"/"+array[1]+"\n";
			                 			}
										}	
			                 }catch(IOException g) {
			                 	g.printStackTrace();
			                 }
			          
			             }catch(FileNotFoundException g) {
			             	g.printStackTrace();
			             }
					
					 	box.setText(chart);
				
				}
				});
		
			
			setSize(500,400 );
			setVisible(true);
	
	}
}

