package user_profile;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class Sign_out extends JFrame{
	
	public Sign_out() 
	{
		setTitle("ȸ�� Ż��");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		JLabel ID = new JLabel("ID                        ");
		JTextField ID_Field = new JTextField(20);
		JLabel PASSWARD = new JLabel("PASSWARD     ");
		JTextField PASSWARD_Field = new JTextField(20);	
		JButton Submit_btn = new JButton("Submit");
		JButton Cancle_btn = new JButton("Cancle");
		c.add(ID);
		c.add(ID_Field);
		c.add(PASSWARD);
		c.add(PASSWARD_Field);
		c.add(Submit_btn);
		c.add(Cancle_btn);
				
		Submit_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String dummy = "";
			String dummy2 = "";
		
			if(ID_Field.getText().equals(IDPW.ID_IN))
			{
				if(PASSWARD_Field.getText().equals(IDPW.PASSWARD_IN))
				{
					String path = IDPW.ID_IN;
					File folder = new File(path);
					try {
					    while(folder.exists()) {
						File[] folder_list = folder.listFiles(); 
								
						for (int j = 0; j < folder_list.length; j++) {
							folder_list[j].delete(); 
				
									
						}
								
						if(folder_list.length == 0 && folder.isDirectory()){ 
							folder.delete();
			
						}
				            }
					 } catch (Exception f) {
						f.getStackTrace();
					}
					try {
						String delData=null;
						String s = null;
						BufferedWriter bw = new BufferedWriter(new FileWriter("MusicChart.txt", true));
						BufferedReader br = new BufferedReader(new FileReader("MusicChart.txt"));
						String line;

						while( (line = br.readLine())!=null) {
		          
		                    s=line;
		                    String[] array = s.split("/");
		               
		                    if(array[2].equals(IDPW.ID_IN))
		        			{
		                    	
		        			}
		                    else {
		                    dummy += (line + "\n" ); 
		                    }
		                } 
					
						FileWriter fw = new FileWriter("MusicChart.txt");

						fw.write(dummy);			


						bw.close();

						fw.close();

						br.close();

					} catch (Exception g) {

						// TODO Auto-generated catch block

						g.printStackTrace();

					}
					try {
						String s = null;
						BufferedReader br1 = new BufferedReader(new FileReader("members.txt"));
						String line;

						while(true) {

		                    line = br1.readLine();
		                    s=line;
		                    String[] array = s.split("/");
		               
		                    if(array[0].equals(IDPW.ID_IN))
		        			{
		        				if(array[1].equals(IDPW.PASSWARD_IN))
		        						{
		        				
		        						break;
		        						}
		        			}
		                    
		                    if(dummy2=="")
		                    dummy2 =line+"\n"; 
		                    else
		                    dummy2=dummy2+line+"\n"; 
		                } 
			
    					
						
						while((line = br1.readLine())!=null) {

							dummy2 += (line + "\n" ); 

						}
			
						
						BufferedWriter bw1 = new BufferedWriter(new FileWriter("members.txt", false));
						bw1.write(dummy2);
						bw1.close();
						br1.close();

					} catch (Exception g) {

						// TODO Auto-generated catch block

						g.printStackTrace();

					}
					
					new user_log();
			    	setVisible(false);
			    	JOptionPane.showMessageDialog(null, "ȸ��Ż�� �Ϸ�!");
				}
			}
			else if(!ID_Field.getText().equals(IDPW.ID_IN)||!PASSWARD_Field.getText().equals(IDPW.PASSWARD_IN))
			{
				JOptionPane.showMessageDialog(null, "�α��� ������ ��ġ���� �ʽ��ϴ�!");
			}

			}
			});
		Cancle_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				new log_in();
			
	
	    	setVisible(false);
	    	
	 
			}
			});
		
		setSize(400,500);
		setVisible(true);
	}

}
