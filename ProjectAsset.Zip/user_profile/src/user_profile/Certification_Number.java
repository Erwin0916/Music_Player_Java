package user_profile;


import javax.swing.*;
import java.awt.*;

public class Certification_Number extends JFrame{
	
	public Certification_Number() {
		
	setTitle("���� ��ȣ");
	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	JLabel Number = new JLabel("������ȣ: 1234 ");
	c.add(Number);

	
	
	setSize(100,100);
	setVisible(true);
	
	}


}
