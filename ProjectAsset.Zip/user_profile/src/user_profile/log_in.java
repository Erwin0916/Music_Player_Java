package user_profile;

import java.io.*;
import javax.sound.sampled.*;

import javax.swing.*;

import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.jaudiotagger.tag.datatype.SynchronisedTempoCode;
import org.jaudiotagger.tag.mp4.Mp4Tag;
import org.jaudiotagger.audio.AudioFile;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.audio.AudioHeader;
import org.jaudiotagger.audio.mp3.MP3AudioHeader;
import org.jaudiotagger.audio.mp3.MP3File;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.id3.AbstractID3v2Frame;
import org.jaudiotagger.tag.id3.AbstractID3v2Tag;
import java.awt.*;
import java.awt.event.*;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Header;
import javazoom.jl.player.Player;
import java.util.Random;

class Artist_info{
	static String artist_name="";
	static String song_name="";
	static String Lyrics="";
	static Image bsImg=null;
}
	
public class log_in extends JFrame{
	
	static JScrollPane			scrollPlayList;
	static JSlider 				timeSlider;
	static String 				part="파일을 재생하면 가사가 표시됩니다.";
	static TextArea defaultText = new TextArea(part);
	static JLabel				currentTimeLabel;
	static JLabel 		runningTimeLabel;
	static JButton btnPlayType = new JButton();
	static int STATE =99;
	static int CUT =98;
	static int PASS =96;
	static long ttt=0;
	static long ttt1=0;
	static long ttt2=0;
	static long fff=0;
	static int cut=0;
	public log_in(){
	setTitle("로그인 된 후 창");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	JButton Log_Out_btn = new JButton("Log Out");
	JButton Sign_Out_btn = new JButton("Sign Out");
	JButton Profile_btn = new JButton("Profile");
	JButton Play_btn = new JButton();
	Play_btn.setIcon(new ImageIcon("icon/play.png"));
	JButton Stop_btn = new JButton();
	Stop_btn.setIcon(new ImageIcon("icon/stop.png"));
	
	JButton Music_Chart_btn = new JButton("음원차트");

	JButton Directory_btn = new JButton("Directory");
	JButton Show_List_btn = new JButton("재생목록");
	JLabel Artist_Name = new JLabel("가수");
	JLabel Song_Name = new JLabel("제목");
	JLabel labelPlayList = new JLabel("Play List");
	JLabel album = new JLabel();
	labelPlayList.setBounds(20, 370, 120, 25);
	labelPlayList.setFocusable(false);
	getContentPane().add(labelPlayList);
	scrollPlayList = new JScrollPane();
	scrollPlayList.setBounds(20, 400, 406, 270);
	scrollPlayList.setFocusable(false);
	JList<?> defaultList = new JList<Object>();
	defaultList.setFocusable(false);
	scrollPlayList.setViewportView(defaultList);
	getContentPane().add(scrollPlayList);
	
	
	JButton btnPrevious = new JButton();
	btnPrevious.setBounds(139, 144, 50, 50);
	JLabel Album = new JLabel();
	ImageIcon tmp = new ImageIcon("icon/streight.png");
	
	btnPlayType.setIcon(tmp);
	
	btnPrevious.setFocusable(false);
	btnPrevious.setBackground(null);
	getContentPane().add(btnPrevious);
	btnPrevious.setIcon(new ImageIcon("icon/next.png"));


	JButton btnNext = new JButton();
	btnNext.setBounds(255, 144, 50, 50);
	
	btnNext.setFocusable(false);
	btnNext.setBackground(null);
	getContentPane().add(btnNext);
	btnNext.setIcon(new ImageIcon("icon/prev.png"));

	currentTimeLabel = new JLabel("00:00");
	currentTimeLabel.setBounds(261, 106, 37, 18);
	currentTimeLabel.setFocusable(false);
	getContentPane().add(currentTimeLabel);


	runningTimeLabel = new JLabel("/ 00:00");
	runningTimeLabel.setBounds(303, 106, 48, 18);
	runningTimeLabel.setFocusable(false);
	getContentPane().add(runningTimeLabel);

	defaultText.setBounds(40,40,200,200);
	c.add(defaultText);
	c.add(Log_Out_btn);
	c.add(Sign_Out_btn);
	c.add(Profile_btn);
	c.add(Stop_btn);
	c.add(Play_btn);
	
	c.add(Directory_btn);
	c.add(Artist_Name);
	c.add(Song_Name);
	c.add(Album);
	c.add(Music_Chart_btn);
	c.add(Show_List_btn);
	c.add(album);
	MP3Player a= new MP3Player();
	Show_List_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			new MyList();
			
		}
		});
	Log_Out_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			MP3Player.close();
			defaultText.setText("");
			PlayList.playlist_clear();
			MP3Player.playState = MP3Player.State.STOP;
			new user_log();
			setVisible(false);
			
		}
		});
	Sign_Out_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
		
			new Sign_out();
			setVisible(false);
			
			
		}
		});
	Profile_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			
			new Profile();
			
		}
		});
	
	Directory_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {	
			OpenFile a =new OpenFile();
			a.actionPerformed(null);
		}
		});
	
    Stop_btn.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			a.stop();
			Play_btn.setIcon(new ImageIcon("icon\\play.png"));
		}
	});

 
    Play_btn.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {
			if(MP3Player.playState!=MP3Player.playState.PLAY )
			{			
			ttt=0;
			a.change(PlayList.getPath());
			a.start();
			
			album.setBounds(12, 530, 294, 261);
			Artist_Name.setText("가수: "+  Artist_info.artist_name);
			Song_Name.setText("제목: "+  Artist_info.song_name);
			Image changeImg = Artist_info.bsImg.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
			ImageIcon changeIcon = new ImageIcon(changeImg);
			album.setIcon(changeIcon);
			updateLyrics(defaultText);
			Play_btn.setIcon(new ImageIcon("icon\\pause.png"));
			}
		}
	});
    
	btnPrevious.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {

			
			a.stop();
			PlayList.prevFile();
			a.change(PlayList.getPath());
			a.start();
			Image changeImg = Artist_info.bsImg.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
			ImageIcon changeIcon = new ImageIcon(changeImg);
			album.setIcon(changeIcon);
			Artist_Name.setText("가수: "+  Artist_info.artist_name);
			Song_Name.setText("제목: "+  Artist_info.song_name);
			
			updateLyrics(defaultText);
		}
	});
btnNext.addActionListener(new ActionListener() {
		public void actionPerformed (ActionEvent e) {					

			
			a.stop();
			PlayList.nextFile();
			a.change(PlayList.getPath());
			a.start();
			Image changeImg = Artist_info.bsImg.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
			ImageIcon changeIcon = new ImageIcon(changeImg);
			album.setIcon(changeIcon);
			Artist_Name.setText("가수: "+  Artist_info.artist_name);
			Song_Name.setText("제목: "+  Artist_info.song_name);
			
			updateLyrics(defaultText);
		}
	});
   
     Music_Chart_btn.addActionListener(new ActionListener() {
  		public void actionPerformed (ActionEvent e) {
  			
  			 new Music_Chart();
  			
  		}
  	});

     class EventbtnPlayPause implements ActionListener {
 		public void actionPerformed (ActionEvent e) {

 			if(MP3Player.playState.equals(MP3Player.State.STOP)) {

 				if (PlayList.getListSize() == 0) {
 					OpenFile open = new OpenFile();
 					open.actionPerformed(null);
 				}
 				else {
 					MP3Player.start(); 
 					Play_btn.setIcon(new ImageIcon("icon/pause.png"));
 				}
 			}
 			else if(MP3Player.playState.equals(MP3Player.State.PLAY)){

 				MP3Player.pause();
 				Play_btn.setIcon(new ImageIcon("icon/play.png"));
 			}
 			else if(MP3Player.playState.equals(MP3Player.State.PAUSE)){
 				
 				MP3Player.restart();
 				Play_btn.setIcon(new ImageIcon("icon/pause.png"));
 			}
 		}
 	}
     repaint();
	setSize(600,900);
	setVisible(true);
	
	}
	public static void updateList(JList<?> playList) {
		scrollPlayList.setViewportView(playList);
		scrollPlayList.setFocusable(false);
	}
	public static void updateLyrics(TextArea defaultText)
	{
		defaultText.setText("");
		defaultText.append(Artist_info.Lyrics);
	}
	public static void updatecurrentTime(long currentTime) {
	
		int min =(int)currentTime / 60;
		int sec =(int)currentTime % 60;
		String time = "";
		if(min < 10) {
			time = "0" + min + ":";
		}
		else {
			time = min + ":";
		}
		if(sec < 10) {
			time = time + "0" + sec;
		}
		else {
			time = time + sec + "";
		}
		currentTimeLabel.setText(time);
		currentTimeLabel.setFocusable(false);
	}

	public static void updaterunningTime(long runningTime) {
		int min = (int) (runningTime) /60;
		int sec = (int) (runningTime) %60;
		String time = "";
		if(min < 10) {
			time = "/ 0" + min + ":";
		}
		else {
			time = "/ " + min + ":";
		}
		if(sec < 10) {
			time = time + "0" + sec;
		}
		else {
			time = time + sec + "";
		}
		
		runningTimeLabel.setText(time);
		runningTimeLabel.setFocusable(false);
	}
class MP3Player {

	enum State{ PLAY, PAUSE, STOP }
	static State playState = State.STOP;
	static Thread timer;
	static AudioInputStream in = null;
	static AudioInputStream din = null;
	static int num=0;

	public static Clip CLIP = null;

	public static File PCMInfo = null;

	public static float savedVolume;
	public static String mp3FileToPlay;
	public static Player jlPlayer;
	
	public MP3Player() {
	        
	    }
	public void change(String a) {
	    	this.mp3FileToPlay =a;
	    }
	public static void start() {
		if (PlayList.getListSize() == 0) {
			OpenFile open = new OpenFile();
			open.actionPerformed(null);
		}
		else {	
			try {
				FileInputStream fileInputStream = new FileInputStream(mp3FileToPlay);
	            BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
	            jlPlayer = new Player(bufferedInputStream);
	            File f=new File(PlayList.getPath()); 
	            MP3File mp3 = (MP3File) AudioFileIO.read(f);                    
	            AbstractID3v2Tag v2Tag = mp3.getID3v2Tag();  
	            Artist_info.artist_name =v2Tag.getFirst(FieldKey.ARTIST); 
	            mp3.setTag(v2Tag); 
	            ImageIcon bsImg = new ImageIcon(v2Tag.getFirstArtwork().getBinaryData());
	            Artist_info.bsImg = bsImg.getImage();
	            Artist_info.song_name=v2Tag.getFirst(FieldKey.TITLE); 
	            Artist_info.Lyrics=v2Tag.getFirst(FieldKey.LYRICS);          
	            log_in.fff =mp3.getAudioHeader().getTrackLength();
	            log_in.updaterunningTime(log_in.fff);
				playState = State.PLAY;
			} catch (Exception e1) {  }
			new Thread() {
	            public void run() {
	                try {
	                    jlPlayer.play();
	                } catch (Exception e) {
	                    System.out.println(e.getMessage());
	                }
	            }
	        }.start();
	    	
		}
	}
	public static void restart() {
		MP3Player.start();
		playState = State.PLAY;
	}
	public static void stop() {
	
		if(!MP3Player.playState.equals(MP3Player.State.STOP)) {
			log_in.updatecurrentTime(0);
			MP3Player.close();
			playState = State.STOP;
		}
	}
	public static void close() {
        if (jlPlayer != null) jlPlayer.close();
    }
	public static void pause() {
		if(!MP3Player.playState.equals(MP3Player.State.PAUSE)) {
			MP3Player.stop();
			playState = State.PAUSE;
		}
	}
	
}
class Timer extends Thread {
	
	boolean interruptFlag = false;
	
	public void run() {
		interruptFlag = false;
			while(log_in.ttt!=log_in.fff) {
			try {
				if(interruptFlag == true) {
					break;
				}
				log_in.ttt++;
				Thread.sleep(1000);
				log_in.updatecurrentTime(log_in.ttt);
				
			} catch (InterruptedException e) {
				return;
			}
		}}
	public void finish() {
		interruptFlag = true;
	}

}
class Timer1 extends Thread {
	
	boolean interruptFlag = false;
	
	public void run() {
		interruptFlag = false;
			while(log_in.ttt1!=log_in.fff) {
			try {
				if(interruptFlag == true) {
					break;
				}
				log_in.ttt1++;
				Thread.sleep(1000);
				log_in.updatecurrentTime(log_in.ttt1);
				
			} catch (InterruptedException e) {
				return;
			}
		}}
	public void finish() {
		interruptFlag = true;
	}

}
class Timer2 extends Thread {
	
	boolean interruptFlag = false;
	
	public void run() {
		interruptFlag = false;
			while(log_in.ttt2!=log_in.fff) {
			try {
				if(interruptFlag == true) {
					break;
				}
				log_in.ttt2++;
				Thread.sleep(1000);
				log_in.updatecurrentTime(log_in.ttt2);
				
			} catch (InterruptedException e) {
				return;
			}
		}}
	public void finish() {
		interruptFlag = true;
	}

}}








