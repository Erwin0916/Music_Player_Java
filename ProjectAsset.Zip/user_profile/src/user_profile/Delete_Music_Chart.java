package user_profile;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Delete_Music_Chart extends JFrame{

	public Delete_Music_Chart(){
		setTitle("��������");
		Container c = getContentPane();
		c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
		JButton submit_btn = new JButton("submit");
		JButton cancle_btn = new JButton("cancle");
		JLabel Song_Name = new JLabel("���: ");
		JTextField Song_Name_Filed = new JTextField(10);
		JLabel Name = new JLabel("���: ");
		JTextField Name_Filed = new JTextField(10);
		
		c.add(Name);
		c.add(Name_Filed);
		c.add(Song_Name);
		c.add(Song_Name_Filed);
		c.add(submit_btn);
		c.add(cancle_btn);

		
		cancle_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	    	setVisible(false);

			}
			});
		
		submit_btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String dummy = "";
				int pass=0;
				String[] array=null;
						try {
							String s = null;
							BufferedWriter bw = new BufferedWriter(new FileWriter("MusicChart.txt", true));
							BufferedReader br = new BufferedReader(new FileReader("MusicChart.txt"));
							String line;

							while(true) {

			                    line = br.readLine();
			                    s=line;
			                    array = s.split("/");
			               
			                    if(array[0].equals(Name_Filed.getText()))
			                    {
			                    	if(array[1].equals(Song_Name_Filed.getText()))
			        						break;			
			                 
			                    }
			                    dummy += (line + "\n" ); 
			                } 

							if(array[0].equals(Name_Filed.getText()))
		        			{
								if(array[1].equals(Song_Name_Filed.getText()))
								{
		        						if(array[2].equals(IDPW.ID_IN)) {
		        							pass=1;	
		        						}
		        						else if(!array[2].equals(IDPW.ID_IN))
		        						{	pass=2;
		        							JOptionPane.showMessageDialog(null, "������ ����� ��Ʈ�� ���� �����մϴ�!");
		        							dummy +=(line + "\n" ); 
		        						}
								}
		        			}
							while((line = br.readLine())!=null) {

								dummy += (line + "\n" ); 

							}
						
							FileWriter fw = new FileWriter("MusicChart.txt");

							fw.write(dummy);			


							bw.close();

							fw.close();

							br.close();
							

						} catch (Exception g) {
							g.printStackTrace();

						}
						if(pass==0)
						{
							JOptionPane.showMessageDialog(null, "��ϵ� �뷡�� �����ϴ�.");
						}
						else if(pass==1)
						{
							JOptionPane.showMessageDialog(null, "���� �Ϸ�!");
						}
				    	setVisible(false);
				    	
					}
			
				});
		
		
		setSize(500,200 );
		setVisible(true);
	
	
	}
}