package user_profile;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class OpenFile implements ActionListener {
	

	
	public void actionPerformed(ActionEvent e) {
		JFileChooser CHOOSER = new JFileChooser();
		
		FileNameExtensionFilter filter = new FileNameExtensionFilter ("WAV, MP3", "wav", "mp3" );
		
		CHOOSER.setFileFilter(filter);
		CHOOSER.setMultiSelectionEnabled(true);

		int ret = CHOOSER.showOpenDialog(null);		
		if ( ret != JFileChooser.APPROVE_OPTION ) {
			JOptionPane.showMessageDialog(null, "������ �������� �ʾҽ��ϴ�.", 
					"���", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		for (File file : CHOOSER.getSelectedFiles()) {
			PlayList.add(file.getPath());
		
		}
	}
}
