package user_profile;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Phone_Certification extends JFrame{
	
	public Phone_Certification() {
		
	setTitle("�޴��� ����");
	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	JLabel PHONE_NUMBER = new JLabel("PHONE NUMBER");
	JTextField PHONE_NUMBER_Field = new JTextField(20);
	JLabel Certification_Number = new JLabel("���� ��ȣ");
	JTextField Certification_Number_Field = new JTextField(20);	
	JButton Send = new JButton("���� ��ȣ ����");
	JButton Submit = new JButton("Submit");
	JButton Back_btn = new JButton("Back");
	JButton Home = new JButton("�α��� ȭ������");
	
	c.add(PHONE_NUMBER);
	c.add(PHONE_NUMBER_Field);
	c.add(Certification_Number);
	c.add(Certification_Number_Field);
	c.add(Send);
	c.add(Submit);
	c.add(Back_btn);
	c.add(Home);
	
	Send.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(!PHONE_NUMBER_Field.getText().equals(IDPW.PHONE_NUMBER_IN))
			{
			JOptionPane.showMessageDialog(null, "�Է��Ͻ� ID�� �޴��� ��ȣ�� ��ġ���� �ʽ��ϴ�.");
			}
			else if(PHONE_NUMBER_Field.getText().equals(IDPW.PHONE_NUMBER_IN))
			{
			JOptionPane.showMessageDialog(null, "������ȣ�� ���۵Ǿ����ϴ�.");
			new Certification_Number();
			
			}
		}
          
		});
	
	Back_btn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			new user_log();
			setVisible(false);
			
		}
		});
	Submit.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			if(!Certification_Number_Field.getText().equals("1234"))
			{
			JOptionPane.showMessageDialog(null, "���� ��ȣ�� ���� �ʽ��ϴ�.");
			}
			else if(Certification_Number_Field.getText().equals("1234"))
			{
			JOptionPane.showMessageDialog(null, "������ �Ϸ�Ǿ����ϴ�.");
			new Information();
			}
		}
          
		});
	Home.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		
			new user_log();
			setVisible(false);
			
		}
		});
	
	setSize(400,500);
	setVisible(true);
	
	}
	
	
	
	

}
