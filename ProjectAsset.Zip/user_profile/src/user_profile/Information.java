package user_profile;


import javax.swing.*;
import java.awt.*;

public class Information extends JFrame{
	
	public Information() {
		
	setTitle("����");
	Container c = getContentPane();
	c.setLayout(new FlowLayout(FlowLayout.LEFT,30,40));
	JLabel ID = new JLabel("ID:");
	JLabel RID = new JLabel(IDPW.ID_IN);
	JLabel PASS = new JLabel("PASSWARD:");
	JLabel RPW = new JLabel(IDPW.PASSWARD_IN);

	c.add(ID);
	c.add(RID);
	c.add(PASS);
	c.add(RPW);
	

	setSize(300,300);
	setVisible(true);
	
	}
	
	
	
	

}
